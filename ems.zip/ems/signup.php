
<?php
session_start();
include 'conn.php';


$nameErr = $pwdErr = $allErr = "";
if ($_SERVER['REQUEST_METHOD'] == "POST") {

	$username = trim($_POST['username']);
	$password = trim($_POST['password']);

	$check = mysqli_query($conn, "select * from users where username = '$username'");
	if (mysqli_num_rows($check) > 0) {
		echo "<script>alert('Username taken, try other'); window.href.location('signup.php');</script>";
	}

	else if (empty($username) || empty($password)) {
		$allErr = "All fields are required";
	}
	else if (!preg_match("/^[a-zA-z]*$/", $username)) {
		$nameErr = "Use valid characters";
	}
	else if (strlen($password) < 6) {
		$pwdErr = "password should be 6 charactes and above";
	}
	else{	$sql  = mysqli_query($conn, "insert into users (username, password) values('$username', '$password')");
	if ($sql == true) {
		
		echo "<script>alert('account created'); window.href.location('index.php');</script>";
	}
	else{
		echo "<script>alert('Error, account not created'); window.href.location('signup.php');</script>";
	}
	}
	

}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Signup</title>
</head>
<body><center>
<form method="post" action="" style="width: 30%; text-align: left;">
	<h3>Create account</h3>
	<label>Username</label><span><?php echo $nameErr; ?></span>
	<input type="text" name="username" placeholder="Enter username">
	<label>Password</label><?php echo $pwdErr; ?></span>
	<input type="password" name="password" placeholder="Enter password">

	<input type="submit" value="Create account">
	<p><?php echo $allErr; ?></span></p>
	<a href="index.php">Login</a>
</form>
</body>
</html>
<style type="text/css">
	<style type="text/css">
	
	form{
		width: 30%;
		padding: 12px;
		text-align: left;
	}
	input[type=text], input[type=number], input[type=password]{
		width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
	} 
	input[type = 'submit']{
width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
		margin-top:5px ;

	}
</style>

