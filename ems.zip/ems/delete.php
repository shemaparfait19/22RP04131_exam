<?php
include 'conn.php';
$id = $_GET['id'];

$sql = mysqli_query($conn, "delete from employees where id = '$id'");
if ($sql) {
	header("location:select.php?record_deleted");
}
else{
	echo "Could not delete record";
}
?>