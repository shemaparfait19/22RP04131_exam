<?php
session_start();
include 'conn.php';
if (!isset($_SESSION['username'])) {
	echo "you need to login first";
}








?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Welcome</title>
</head>
<body>
<h3>Employee Managment System
	
<span class="left" style="position: relative; right: -780px;">Welcome <?php echo $_SESSION['username'];?> <span><a href="logout.php">Logout</a> </span></h3> 
<br>
</body>
</html>

