
<?php
session_start();
include 'conn.php';
if (!isset($_SESSION['username'])) {
	echo "you need to login first";
}
else{

$aErr = $bErr = $cErr = $dErr = $eErr =$allErr = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

	$employee_name = trim($_POST['employee_name']);
	$email = trim($_POST['email']);
	$phone = trim($_POST['phone']);
	$position = trim($_POST['position']);
	$address = trim($_POST['address']);	

if (empty($employee_name) || empty($email) || empty($phone) || empty($position) || empty($address) ) {
	$allErr = "Fields are required";
}
else if(!preg_match("/^[a-zA-z]*$/", $employee_name)){
	$aErr = "use valid characters";
}
else if (!preg_match("/^[0-9]{10}$/", $phone)) {
            $cErr = "Phone number must be 10 digits long";
        }

else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
	$bErr = "Invalid email";

}
	
		else {
			$sql = mysqli_query($conn, "insert into employees(employee_name, email, phone, position, address) values('$employee_name','$email','$phone','$position','$address') ");
		if ($sql) {
			header("location:select.php?record_inserted");
		}
		else{
			echo "Could not insert data";
		}
}
}
	






?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Record a student</title>
</head>
<body>	<h3><a href="welcome.php" style="text-decoration: none;">Employee Managment System </a>
	
<span class="left" style="position: relative; right: -740px;">Welcome <?php echo $_SESSION['username'];?> <span><a href="logout.php">Logout</a> </span></h3> 
<br><center>
<form method="post" action="">
	<h3>Record data</h3>
	
	<label>Empoyee name</label><span class="error"><?php echo $aErr?> </span>

	<input type="text" name="employee_name">

	<label>email</label>

	<input type="email" name="email">
	<label>position</label>

	<input type="text" name="position">


	<label>phone</label> <?php echo $cErr?> </span>

	<input type="text" name="phone">

	
	<label>address</label>

	<input type="text" name="address">

	<input type="submit" value="Submit">
	<p><?php echo $allErr;?></p>
</form>
</body>
</html>
<?php } ?>

<style type="text/css">
	
	form{
		width: 30%;
		padding: 12px;
		text-align: left;
	}
	input[type=text], input[type=number], input[type=email]{
		width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
	} 
	input[type = 'submit']{
width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
		margin-top:5px ;

	}
	button{
		padding: 12px;
		border: ;
		color: blue;
	}
</style>