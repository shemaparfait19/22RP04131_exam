
<?php

session_start();
include 'conn.php';
if (!isset($_SESSION['username'])) {
	echo "you need to login first";
}
else{



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h3><a href="welcome.php" style="text-decoration: none;">Employee Managment System </a>
	
<span class="left" style="position: relative; right: -740px;">Welcome <?php echo $_SESSION['username'];?> <span><a href="logout.php">Logout</a>  </span></h3> 
<br>
	<CENTER>


<a href="insert.php"><button>Record employee</button></a> &nbsp; <a href="select.php"><button>View employees</button></a>
</body>
</html>
<?php } ?>	
<style type="text/css">
	
	button{
		padding: 12px;
		border: ;
		color: blue;
		cursor: pointer;
	}
</style>

