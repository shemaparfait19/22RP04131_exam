

<?php

session_start();
include 'conn.php';
if (!isset($_SESSION['username'])) {
	echo "you need to login first";
}
else{

$sql = mysqli_query($conn, "select * from employees");
echo "<div class='center'> <a href ='welcome.php'> <button> Return</button> </a> </a><center>";
echo "<a href='insert.php'><button>Add Record</button></a><br><br>";
echo "<table border='1' style='border-collapse:collapse;' cellpadding='4'> <th>No</th> <th>Employee Name</th> <th>Email</th> <th>phone</th> <th>position</th> <th>address</th> <th>Created at</th> <th>Action</th>";
$a = 0;
while($row = mysqli_fetch_array($sql)){

$a++;


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	
	<tr> <td><?php echo $a ?></td> 
		<td><?php echo $row['employee_name']; ?></td> 
		<td><?php echo $row['email']; ?></td> 
		<td><?php echo $row['phone']; ?></td> 
		<td><?php echo $row['position']; ?></td> 
		<td><?php echo $row['address']; ?></td> 
		<td><?php echo $row['created_at']; ?></td>  
		<td colspan="2"><a href="delete.php?id=<?php echo $row['id'];?>">Delete</a> &nbsp; <a href="update.php?id=<?php echo $row['id'];?>">Update</a></td>
		 </tr>

<?php } } ?>
</body>
</html>
<style type="text/css">
	button{
		padding: 12px;
		border: ;
		color: blue;
		cursor: pointer;
	}
</style>