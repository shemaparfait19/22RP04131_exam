<?php
$conn = mysqli_connect("localhost","root","","nextech_portal_22rp04131") or die("could not connect");

?>