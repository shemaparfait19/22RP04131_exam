
<?php
session_start();
include 'conn.php';


$nameErr = $pwdErr = $allErr = "";
if ($_SERVER['REQUEST_METHOD'] == "POST") {

	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	
	if (isset($_POST['remember'])) {
		setcookie("cookie", $username, time() + 60 * 60 * 24 * 7);
		isset($_COOKIE['cookie']);
	}

	if (empty($username) || empty($password)) {
		$allErr = "All fields are required";
	}
	else if (!preg_match("/^[a-zA-z]*$/", $username)) {
		$nameErr = "Use valid characters";
	}
	else{	$sql  = mysqli_query($conn, "select * from users where username = '$username' and password = '$password'");
	if (mysqli_num_rows($sql) > 0) {
		$_SESSION['username'] = $username;
		header("location:welcome.php");
	}
	else{
		echo "<script>alert('Invalid username or password'); window.href.location('index.php');</script>";
	}
	}
	

}


?>
<!DOCTYPE html>
<html>
<head><center>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>
<form method="post" action="" style="width: 30%; text-align: left;">
	<h3>Login</h3>
	<label>Username</label><span><?php echo $nameErr; ?></span>
	<input type="text" name="username" placeholder="Enter username">
	<label>Password</label><?php echo $pwdErr; ?></span>
	<input type="password" name="password" placeholder="Enter password">

	<label>Remember me</label>
	<input type="checkbox" name="remember">
	<input type="submit" value="Login">
	<p><?php echo $allErr; ?></span></p>
	<a href="signup.php">Create an account </a>
</form>
</body>
</html>
<style type="text/css">
	<style type="text/css">
	
	form{
		width: 30%;
		padding: 12px;
		text-align: left;
	}
	input[type=text], input[type=number], input[type=password]{
		width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
	} 
	input[type = 'submit']{
width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
		margin-top:5px ;


	}
	button{
		padding: 12px;
		border: none;
		color: blue;
	}
</style>

