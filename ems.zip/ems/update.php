<?php
session_start();
include 'conn.php';
if (!isset($_SESSION['username'])) {
	echo "you need to login first";
}
else{
$id = $_GET['id'];
$sql2 = mysqli_query($conn , "select * from employees where id = '$id'");
if($row = mysqli_fetch_array($sql2)){
	$a = $row['employee_name'];
	$b = $row['email'];
	$c = $row['phone'];
	$d = $row['position'];
	$e = $row['address'];
}



?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<h3><a href="welcome.php" style="text-decoration: none;">Employee Managment System </a>
	
<span class="left" style="position: relative; right: -740px;">Welcome <?php echo $_SESSION['username'];?> <span><a href="logout.php">Logout</a>  </span></h3> 
<br><center>
	<form method="post" action="">
	<h3>Update data</h3>
	<label>Empoyee name</label>

	<input type="text" name="employee_name" value="<?php echo $a; ?>">

	<label>email</label>

	<input type="email" name="email" value="<?php echo $b; ?>">
	<label>position</label>

	<input type="text" name="position" value="<?php echo $c; ?>">


	<label>phone</label>

	<input type="text" name="phone" value="<?php echo $d; ?>">

	
	<label>address</label>

	<input type="text" name="address" value="<?php echo $e; ?>">

	<input type="submit" value="Update">
	
</form>

</body>
</html>
<?php 

$aErr = $bErr = $cErr = $dErr = $eErr =$allErr = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

	$employee_name = trim($_POST['employee_name']);
	$email = trim($_POST['email']);
	$phone = trim($_POST['phone']);
	$position = trim($_POST['position']);
	$address = trim($_POST['address']);	

if (empty($employee_name) || empty($email) || empty($phone) || empty($position) || empty($address) ) {
	$allErr = "Fields are required";
}
else if(!preg_match("/^[a-zA-z]*$/", $emp)){
	$aErr = "use valid characters";
}
else if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
	$bErr = "Invalid email";

}
	
		else {
			$sql = mysqli_query($conn, "update employees set employee_name = '$employee_name', email ='$email', phone = '$phone', position = '$position', address = '$address' where id = '$id' ");
		if ($sql) {
			header("location:select.php?record_updated");
		}
		else{
			echo "Could not update data";
		}
}
}
	}

?>
<style type="text/css">
	<style type="text/css">
	
	form{
		width: 30%;
		padding: 12px;
		text-align: left;
	}
	input[type=text], input[type=number], input[type=email]{
		width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
	} 
	input[type = 'submit']{
width: 100%;
		padding: 12px 20px;
		box-sizing: border-box;
		margin-top:5px ;

	}
</style>